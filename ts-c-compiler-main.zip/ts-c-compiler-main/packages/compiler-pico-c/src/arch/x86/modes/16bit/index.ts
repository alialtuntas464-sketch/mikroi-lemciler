export * from './sizeofPrimitiveType';
