export * from './IsNewScopeASTNode';
