# @ts-cc/vm

## 1.8.0

### Minor Changes

- Better C support

## 1.7.1

### Patch Changes

- Force publish machine

## 1.7.0

### Minor Changes

- Publish packages

## 1.6.0

### Minor Changes

- Fix changesets

## 1.5.0

### Minor Changes

- Improve C support

## 1.4.0

### Minor Changes

- Improve C support

## 1.3.0

### Minor Changes

- Add more new things

## 1.2.0

### Minor Changes

- Add web vm
